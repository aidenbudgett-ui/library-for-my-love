# BookNest
A responsive personal book-library website prototype.

## Run it
Open `index.html` in a modern browser. No build step is required.

## Included
- Responsive desktop/mobile layout
- Search bar for titles and authors
- Shows whether a book is already in the user's library
- Add-to-library interaction
- Library statistics
- Personalized-style recommendation section
- Starter catalog and sample library

## Next development steps
1. Connect a real book API (Open Library or Google Books).
2. Add user accounts and a database.
3. Save each user's library, ratings, favorites, and reading status.
4. Build a recommendation engine using genres, authors, ratings, and reading history.
5. Add ISBN scanning and book-detail pages.
