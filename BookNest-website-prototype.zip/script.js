const library = [
  {title:"The Hobbit",author:"J.R.R. Tolkien",rating:5,owned:true,color:"#a97848"},
  {title:"Dune",author:"Frank Herbert",rating:5,owned:true,color:"#b26e45"},
  {title:"Harry Potter and the Sorcerer's Stone",author:"J.K. Rowling",rating:5,owned:true,color:"#6b587b"},
  {title:"The Name of the Wind",author:"Patrick Rothfuss",rating:4,owned:true,color:"#4d665d"},
  {title:"Project Hail Mary",author:"Andy Weir",rating:5,owned:true,color:"#496b78"},
  {title:"The Martian",author:"Andy Weir",rating:4,owned:true,color:"#a4543e"}
];
const catalog = [
  ...library,
  {title:"Mistborn: The Final Empire",author:"Brandon Sanderson",rating:5,owned:false,color:"#4f5b68"},
  {title:"The Way of Kings",author:"Brandon Sanderson",rating:5,owned:false,color:"#6b4e55"},
  {title:"Ender's Game",author:"Orson Scott Card",rating:4,owned:false,color:"#415f6b"},
  {title:"The Left Hand of Darkness",author:"Ursula K. Le Guin",rating:4,owned:false,color:"#556d63"},
  {title:"Good Omens",author:"Neil Gaiman & Terry Pratchett",rating:4,owned:false,color:"#7d6248"},
  {title:"The Ocean at the End of the Lane",author:"Neil Gaiman",rating:4,owned:false,color:"#4d6174"}
];

const $ = s => document.querySelector(s);
function stars(n){return "★".repeat(n)+"☆".repeat(5-n)}
function card(b){
  return `<article class="book-card">
    <div class="cover" style="background:${b.color}">${b.title}</div>
    <div class="card-body">
      <h3>${b.title}</h3><div class="author">${b.author}</div>
      <div class="rating">${stars(b.rating)}</div>
      ${b.owned ? '<span class="status">✓ In your library</span>' : '<span class="status not-owned">Not in your library</span><button class="add" data-add="'+b.title+'">+ Add to library</button>'}
    </div>
  </article>`
}
function renderLibrary(){
  $("#libraryGrid").innerHTML = library.map(card).join("");
  $("#bookCount").textContent = library.length;
}
function renderRecommendations(){
  const recs = catalog.filter(b=>!b.owned).slice(0,4);
  $("#recommendationGrid").innerHTML = recs.map(card).join("");
}
function doSearch(q){
  q=q.trim();
  $("#clearSearch").hidden=!q;
  if(!q){$("#searchResults").classList.add("hidden");return}
  const words=q.toLowerCase().split(/\s+/);
  const matches=catalog.filter(b=>(b.title+" "+b.author).toLowerCase().includes(q.toLowerCase()) ||
    words.some(w=>(b.title+" "+b.author).toLowerCase().includes(w)));
  $("#searchResults").classList.remove("hidden");
  $("#resultCount").textContent=`${matches.length} result${matches.length===1?"":"s"}`;
  $("#resultsGrid").innerHTML=matches.length ? matches.map(card).join("") :
    `<p class="muted">No books found. Try another title or author.</p>`;
  $("#searchResults").scrollIntoView({behavior:"smooth",block:"start"});
}
$("#search").addEventListener("input",e=>doSearch(e.target.value));
$("#clearSearch").addEventListener("click",()=>{$("#search").value="";doSearch("")});
document.querySelectorAll(".quick-search button").forEach(b=>b.addEventListener("click",()=>{
  $("#search").value=b.dataset.query;doSearch(b.dataset.query)
}));
document.addEventListener("click",e=>{
  const btn=e.target.closest("[data-add]");
  if(!btn)return;
  const b=catalog.find(x=>x.title===btn.dataset.add);
  if(b && !b.owned){b.owned=true;library.push(b);renderLibrary();renderRecommendations();doSearch($("#search").value)}
});
renderLibrary();renderRecommendations();