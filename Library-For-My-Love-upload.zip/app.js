const CFG = window.BOOKNEST_CONFIG || {};
const hasSupabaseConfig = CFG.supabaseUrl && !CFG.supabaseUrl.includes("YOUR-PROJECT") &&
  CFG.supabasePublishableKey && !CFG.supabasePublishableKey.includes("YOUR-PUBLISHABLE-KEY");

const sb = hasSupabaseConfig ? window.supabase.createClient(CFG.supabaseUrl, CFG.supabasePublishableKey, {
  auth: { persistSession: true, autoRefreshToken: true, detectSessionInUrl: true }
}) : null;

const OPEN_LIBRARY = "https://openlibrary.org/search.json";
const state = {
  session: null,
  library: [],
  searchResults: new Map(),
  searchTimer: null,
  filter: "all",
  authMode: "signin",
  scannerStream: null,
  recommendations: []
};

const $ = s => document.querySelector(s);

function escapeHtml(value=""){
  return String(value).replace(/[&<>"']/g, ch => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[ch]));
}
function toast(message){
  const el = $("#toast"); el.textContent = message; el.classList.add("show");
  clearTimeout(toast.timer); toast.timer = setTimeout(()=>el.classList.remove("show"), 2600);
}
function setStatus(message, error=false){
  $("#apiMessage").textContent = message || "";
  $("#apiMessage").style.color = error ? "var(--danger)" : "";
}
function stars(n){
  if(!n) return "";
  const r=Math.max(0,Math.min(5,Math.round(n)));
  return "★".repeat(r)+"☆".repeat(5-r);
}
function openModal(id){ $( "#"+id ).classList.remove("hidden"); }
function closeModal(id){
  $("#"+id).classList.add("hidden");
  if(id==="scannerModal") stopScanner();
}
document.addEventListener("click", e=>{
  const close=e.target.closest("[data-close]");
  if(close) closeModal(close.dataset.close);
  if(e.target.classList.contains("modal")) e.target.classList.add("hidden");
});

function normalized(doc){
  return {
    key: doc.key || `title:${doc.title}|author:${(doc.author_name||[])[0]||""}`,
    title: doc.title || "Untitled",
    author: (doc.author_name||[])[0] || "Unknown author",
    cover_i: doc.cover_i || null,
    isbn: (doc.isbn||[])[0] || "",
    first_publish_year: doc.first_publish_year || "",
    subjects: (doc.subject||[]).slice(0,12),
    rating: Number(doc.ratings_average) || 0,
    ratings_count: Number(doc.ratings_count) || 0
  };
}

function cover(book, large=false){
  if(book.cover_i){
    return `<img class="${large?"detail-cover":"book-cover-img"}" src="https://covers.openlibrary.org/b/id/${book.cover_i}-${large?"L":"M"}.jpg" alt="Cover of ${escapeHtml(book.title)}" loading="lazy">`;
  }
  return `<div class="${large?"detail-cover detail-cover-fallback":"cover"}">${escapeHtml(book.title)}</div>`;
}

function libraryEntry(bookRow){
  return {
    relationId: bookRow.id,
    bookId: bookRow.book_id,
    key: bookRow.books.open_library_key,
    title: bookRow.books.title,
    author: bookRow.books.author,
    cover_i: bookRow.books.cover_id,
    isbn: bookRow.books.isbn,
    first_publish_year: bookRow.books.first_publish_year,
    subjects: bookRow.books.subjects || [],
    status: bookRow.status,
    rating: bookRow.rating || 0,
    favorite: !!bookRow.favorite,
    notes: bookRow.notes || ""
  };
}

function isLoggedIn(){ return !!state.session; }

async function getSession(){
  if(!sb) return null;
  const {data} = await sb.auth.getSession();
  state.session = data.session;
  return state.session;
}

async function loadLibrary(){
  if(!sb || !state.session){ state.library=[]; renderLibrary(); renderRecommendations([]); return; }
  const {data,error} = await sb.from("user_books")
    .select("id,book_id,status,rating,favorite,notes,books(id,open_library_key,title,author,cover_id,isbn,first_publish_year,subjects)")
    .order("updated_at",{ascending:false});
  if(error){ console.error(error); toast("Couldn't load your library."); return; }
  state.library=(data||[]).map(libraryEntry);
  renderLibrary();
  await buildRecommendations();
}

function renderLibrary(){
  const total=state.library.length;
  $("#bookCount").textContent=total;
  $("#readingCount").textContent=state.library.filter(x=>x.status==="reading").length;
  $("#wantCount").textContent=state.library.filter(x=>x.status==="want_to_read").length;
  $("#finishedCount").textContent=state.library.filter(x=>x.status==="finished").length;
  $("#favoriteCount").textContent=state.library.filter(x=>x.favorite).length;

  let books=state.library;
  if(state.filter==="favorite") books=books.filter(x=>x.favorite);
  else if(state.filter!=="all") books=books.filter(x=>x.status===state.filter);

  $("#libraryEmpty").classList.toggle("hidden",books.length>0);
  $("#libraryEmpty").textContent = isLoggedIn()
    ? (total ? "No books match this filter." : "Your library is empty. Search for a book above and add it.")
    : "Sign in and add books to build your library.";

  $("#libraryGrid").innerHTML=books.map(libraryCard).join("");
}

function libraryCard(book){
  return `<article class="book-card">
    <div class="cover">${cover(book)}</div>
    <div class="card-body">
      <h3>${escapeHtml(book.title)}</h3>
      <div class="author">${escapeHtml(book.author)}</div>
      ${book.rating ? `<div class="rating">${stars(book.rating)}</div>`:""}
      <div class="library-controls">
        <select class="status-select" data-status="${book.relationId}">
          <option value="want_to_read" ${book.status==="want_to_read"?"selected":""}>Want to read</option>
          <option value="reading" ${book.status==="reading"?"selected":""}>Reading</option>
          <option value="finished" ${book.status==="finished"?"selected":""}>Finished</option>
        </select>
        <button class="favorite-button ${book.favorite?"active":""}" data-favorite="${book.relationId}" title="Favorite">♥</button>
      </div>
      <div class="card-actions">
        <button class="details-button" data-detail="${escapeHtml(book.key)}">Details</button>
        <button class="remove" data-remove="${book.relationId}">Remove</button>
      </div>
    </div>
  </article>`;
}

function searchCard(book){
  const owned=state.library.some(x=>x.key===book.key);
  return `<article class="book-card">
    <div class="cover">${cover(book)}</div>
    <div class="card-body">
      <h3>${escapeHtml(book.title)}</h3>
      <div class="author">${escapeHtml(book.author)}</div>
      ${book.rating?`<div class="rating">${stars(book.rating)}</div>`:""}
      ${book.first_publish_year?`<div class="meta">First published ${book.first_publish_year}</div>`:""}
      ${owned
        ? `<span class="status">✓ In your library</span>`
        : `<span class="status not-owned">Not in your library</span>`}
      <div class="card-actions">
        <button class="details-button" data-detail="${escapeHtml(book.key)}">Details</button>
        ${owned
          ? `<button class="remove" data-remove-key="${escapeHtml(book.key)}">Remove</button>`
          : `<button class="add" data-add="${escapeHtml(book.key)}">+ Add</button>`}
      </div>
    </div>
  </article>`;
}

async function searchBooks(query, limit=12){
  const url=`${OPEN_LIBRARY}?q=${encodeURIComponent(query)}&limit=${limit}&fields=key,title,author_name,cover_i,isbn,first_publish_year,subject,ratings_average,ratings_count`;
  const res=await fetch(url);
  if(!res.ok) throw new Error("Open Library search failed");
  const data=await res.json();
  return (data.docs||[]).map(normalized);
}

async function doSearch(query){
  const q=query.trim();
  $("#clearSearch").hidden=!q;
  if(!q){ $("#searchResults").classList.add("hidden"); setStatus(""); return; }
  $("#searchResults").classList.remove("hidden");
  $("#resultsGrid").innerHTML=`<div class="loading">Searching the book catalog…</div>`;
  setStatus("Searching Open Library…");
  try{
    const results=await searchBooks(q);
    state.searchResults=new Map(results.map(b=>[b.key,b]));
    $("#resultCount").textContent=`${results.length} result${results.length===1?"":"s"}`;
    $("#resultsGrid").innerHTML=results.length?results.map(searchCard).join(""):`<div class="empty-state">No books found. Try another title, author, or ISBN.</div>`;
    setStatus("Search results powered by Open Library.");
    $("#searchResults").scrollIntoView({behavior:"smooth",block:"start"});
  }catch(e){
    console.error(e); $("#resultsGrid").innerHTML=`<div class="error">Book search failed. Check your connection and try again.</div>`; setStatus("",true);
  }
}

function saveBookToCatalog(book){
  return sb.from("books").upsert({
    open_library_key:book.key,title:book.title,author:book.author,cover_id:book.cover_i,
    isbn:book.isbn,first_publish_year:book.first_publish_year||null,subjects:book.subjects||[]
  },{onConflict:"open_library_key"}).select("id").single();
}

async function addBook(book){
  if(!sb || !state.session){ openAuth("signin"); toast("Sign in to save books to your library."); return; }
  if(state.library.some(x=>x.key===book.key)){ toast("That book is already in your library."); return; }
  const {data:catalogBook,error:catalogError}=await saveBookToCatalog(book);
  if(catalogError){console.error(catalogError);toast("Couldn't save the book.");return;}
  const {error}=await sb.from("user_books").insert({
    user_id:state.session.user.id,book_id:catalogBook.id,status:"want_to_read",rating:null,favorite:false
  });
  if(error){
    if(error.code==="23505") toast("That book is already in your library.");
    else {console.error(error);toast("Couldn't add the book.");}
    return;
  }
  toast("Added to your library.");
  await loadLibrary();
  await doSearch($("#search").value);
}

async function removeRelation(id){
  if(!sb || !state.session)return;
  const {error}=await sb.from("user_books").delete().eq("id",id);
  if(error){console.error(error);toast("Couldn't remove the book.");return;}
  toast("Removed from your library.");
  await loadLibrary();
  if($("#search").value) await doSearch($("#search").value);
}

async function removeByKey(key){
  const item=state.library.find(x=>x.key===key);
  if(item) await removeRelation(item.relationId);
}

async function updateRelation(id, patch){
  if(!sb || !state.session)return;
  const {error}=await sb.from("user_books").update(patch).eq("id",id);
  if(error){console.error(error);toast("Couldn't update the book.");return;}
  await loadLibrary();
}

async function openDetails(key){
  let book=state.searchResults.get(key)||state.library.find(x=>x.key===key);
  if(!book)return;
  $("#detailContent").innerHTML=`<div class="loading">Loading book details…</div>`;
  openModal("detailModal");
  try{
    // Search by exact title to obtain a richer subject list.
    const results=await searchBooks(`title:"${book.title}"`,8);
    const richer=results.find(x=>x.key===key)||results[0]||book;
    const owned=state.library.find(x=>x.key===richer.key);
    const subjects=(richer.subjects||[]).slice(0,10);
    $("#detailContent").innerHTML=`
      <div class="detail-layout">
        <div>${cover(richer,true)}</div>
        <div>
          <p class="eyebrow">BOOK DETAILS</p>
          <h2 id="detailTitle">${escapeHtml(richer.title)}</h2>
          <p class="muted">${escapeHtml(richer.author)}</p>
          ${richer.first_publish_year?`<p class="meta">First published ${richer.first_publish_year}</p>`:""}
          ${richer.isbn?`<p class="meta">ISBN: ${escapeHtml(richer.isbn)}</p>`:""}
          ${subjects.length?`<div class="subject-list">${subjects.map(s=>`<span class="subject">${escapeHtml(s)}</span>`).join("")}</div>`:""}
          <div class="detail-actions">
            ${owned
              ? `<p class="status">✓ In your library</p>
                 <div class="library-controls">
                   <select class="status-select" data-status="${owned.relationId}">
                     <option value="want_to_read" ${owned.status==="want_to_read"?"selected":""}>Want to read</option>
                     <option value="reading" ${owned.status==="reading"?"selected":""}>Reading</option>
                     <option value="finished" ${owned.status==="finished"?"selected":""}>Finished</option>
                   </select>
                   <button class="favorite-button ${owned.favorite?"active":""}" data-favorite="${owned.relationId}">♥</button>
                 </div>
                 <div class="rating-picker">
                   <p class="meta">Your rating</p>
                   <select class="rating-select" data-rating="${owned.relationId}">
                     <option value="">No rating</option>
                     ${[1,2,3,4,5].map(n=>`<option value="${n}" ${owned.rating===n?"selected":""}>${n} star${n>1?"s":""}</option>`).join("")}
                   </select>
                 </div>`
              : `<button class="primary-button" data-add-detail="${escapeHtml(richer.key)}">+ Add to library</button>`}
          </div>
        </div>
      </div>`;
    state.searchResults.set(richer.key,richer);
  }catch(e){ console.error(e); $("#detailContent").innerHTML=`<div class="error">Couldn't load additional book details.</div>`; }
}

function openAuth(mode="signin"){
  state.authMode=mode;
  $("#authTitle").textContent=mode==="signin"?"Sign in":"Create your account";
  $("#authSubmit").textContent=mode==="signin"?"Sign in":"Create account";
  $("#authMode").textContent=mode==="signin"?"Create an account instead":"I already have an account";
  $("#displayNameLabel").classList.toggle("hidden",mode==="signin");
  $("#resetPassword").classList.toggle("hidden",mode!=="signin");
  $("#authStatus").textContent="";
  openModal("authModal");
}

async function submitAuth(e){
  e.preventDefault();
  if(!sb){ $("#authStatus").textContent="Connect Supabase first using the setup guide."; return; }
  const email=$("#authEmail").value.trim(),password=$("#authPassword").value;
  $("#authStatus").textContent="Working…";
  if(state.authMode==="signup"){
    const displayName=$("#displayName").value.trim();
    const {data,error}=await sb.auth.signUp({email,password,options:{data:{display_name:displayName}}});
    if(error){$("#authStatus").textContent=error.message;return;}
    if(data.session){ state.session=data.session; closeModal("authModal"); await refreshAuth(); }
    else $("#authStatus").textContent="Check your email to confirm your account, then sign in.";
  }else{
    const {data,error}=await sb.auth.signInWithPassword({email,password});
    if(error){$("#authStatus").textContent=error.message;return;}
    state.session=data.session; closeModal("authModal"); await refreshAuth(); toast("Welcome back.");
  }
}

async function resetPassword(){
  if(!sb){toast("Connect Supabase first.");return;}
  const email=$("#authEmail").value.trim();
  if(!email){$("#authStatus").textContent="Enter your email first.";return;}
  const {error}=await sb.auth.resetPasswordForEmail(email,{redirectTo:location.origin+location.pathname});
  $("#authStatus").textContent=error?error.message:"Password reset email sent.";
}

async function refreshAuth(){
  await getSession();
  if(state.session){
    const email=state.session.user.email||"";
    $("#userLabel").textContent=email;
    $("#accountButton").title=email;
    $("#accountEmail").textContent=email;
  }else{
    $("#userLabel").textContent="";
    $("#accountButton").title="Sign in";
  }
  renderLibrary();
  await loadLibrary();
}

async function buildRecommendations(){
  if(!state.session || !state.library.length){
    state.recommendations=[]; renderRecommendations(); return;
  }
  const ranked={};
  const seed=state.library.slice(0,6);
  try{
    for(const item of seed){
      const queries=[];
      if(item.author) queries.push(`author:"${item.author}"`);
      for(const subject of (item.subjects||[]).slice(0,2)) queries.push(`subject:"${subject}"`);
      for(const q of queries){
        const results=await searchBooks(q,8);
        for(const b of results){
          if(state.library.some(x=>x.key===b.key))continue;
          const score=(b.author===item.author?5:0)+(b.subjects||[]).filter(s=>(item.subjects||[]).includes(s)).length;
          ranked[b.key]=(ranked[b.key]||{book:b,score:0});
          ranked[b.key].score+=score;
        }
      }
    }
    state.recommendations=Object.values(ranked).sort((a,b)=>b.score-a.score).slice(0,8).map(x=>x.book);
    renderRecommendations();
  }catch(e){console.error(e);renderRecommendations();}
}

function renderRecommendations(){
  const recs=state.recommendations||[];
  $("#recommendationEmpty").classList.toggle("hidden",recs.length>0);
  $("#recommendationGrid").innerHTML=recs.slice(0,8).map(searchCard).join("");
}

async function startScanner(){
  if(!("BarcodeDetector" in window)){toast("This browser doesn't support built-in barcode scanning. You can search the ISBN manually.");return;}
  if(!navigator.mediaDevices?.getUserMedia){toast("Camera access isn't available here.");return;}
  try{
    const detector=new BarcodeDetector({formats:["ean_13","ean_8","upc_a","upc_e"]});
    state.scannerStream=await navigator.mediaDevices.getUserMedia({video:{facingMode:{ideal:"environment"}}});
    $("#scannerVideo").srcObject=state.scannerStream;
    await $("#scannerVideo").play();
    $("#scannerStatus").textContent="Scanning…";
    openModal("scannerModal");
    state.scannerLoop=true;
    const scan=async()=>{
      if(!state.scannerLoop)return;
      try{
        const codes=await detector.detect($("#scannerVideo"));
        if(codes.length && codes[0].rawValue){
          const isbn=codes[0].rawValue;
          stopScanner(); closeModal("scannerModal");
          $("#search").value=isbn; await doSearch(isbn); return;
        }
      }catch(e){}
      requestAnimationFrame(scan);
    };
    requestAnimationFrame(scan);
  }catch(e){console.error(e);toast("Camera permission was denied or unavailable.");}
}
function stopScanner(){
  state.scannerLoop=false;
  if(state.scannerStream){state.scannerStream.getTracks().forEach(t=>t.stop());state.scannerStream=null;}
  const v=$("#scannerVideo"); if(v)v.srcObject=null;
}

document.addEventListener("change",async e=>{
  const s=e.target.closest("[data-status]");
  if(s) await updateRelation(Number(s.dataset.status),{status:s.value});
  const r=e.target.closest("[data-rating]");
  if(r) await updateRelation(Number(r.dataset.rating),{rating:r.value?Number(r.value):null});
});
document.addEventListener("click",async e=>{
  const add=e.target.closest("[data-add]");
  if(add){const book=state.searchResults.get(add.dataset.add);if(book)await addBook(book);return;}
  const addDetail=e.target.closest("[data-add-detail]");
  if(addDetail){const book=state.searchResults.get(addDetail.dataset.addDetail);if(book){await addBook(book);closeModal("detailModal");}return;}
  const rem=e.target.closest("[data-remove]");
  if(rem){await removeRelation(Number(rem.dataset.remove));return;}
  const remKey=e.target.closest("[data-remove-key]");
  if(remKey){await removeByKey(remKey.dataset.removeKey);return;}
  const fav=e.target.closest("[data-favorite]");
  if(fav){const item=state.library.find(x=>x.relationId===Number(fav.dataset.favorite));if(item)await updateRelation(item.relationId,{favorite:!item.favorite});return;}
  const detail=e.target.closest("[data-detail]");
  if(detail){await openDetails(detail.dataset.detail);return;}
  const filter=e.target.closest("[data-filter]");
  if(filter){document.querySelectorAll(".filter").forEach(x=>x.classList.remove("active"));filter.classList.add("active");state.filter=filter.dataset.filter;renderLibrary();return;}
});

$("#searchForm").addEventListener("submit",e=>{e.preventDefault();doSearch($("#search").value);});
$("#search").addEventListener("input",e=>{
  clearTimeout(state.searchTimer);
  const q=e.target.value;
  if(!q.trim()){doSearch("");return;}
  state.searchTimer=setTimeout(()=>doSearch(q),450);
});
$("#clearSearch").addEventListener("click",()=>{$("#search").value="";doSearch("");$("#search").focus();});
document.querySelectorAll(".quick-search button").forEach(b=>b.addEventListener("click",()=>{$("#search").value=b.dataset.query;doSearch(b.dataset.query);}));
$("#accountButton").addEventListener("click",()=>state.session?openModal("accountModal"):openAuth("signin"));
$("#authForm").addEventListener("submit",submitAuth);
$("#authMode").addEventListener("click",()=>openAuth(state.authMode==="signin"?"signup":"signin"));
$("#resetPassword").addEventListener("click",resetPassword);
$("#signOutButton").addEventListener("click",async()=>{if(sb)await sb.auth.signOut();closeModal("accountModal");state.session=null;state.library=[];await refreshAuth();toast("Signed out.");});
$("#scanButton").addEventListener("click",startScanner);
$("#stopScanner").addEventListener("click",()=>{stopScanner();closeModal("scannerModal");});

async function init(){
  if(!sb){
    setStatus("Demo mode: connect Supabase to enable accounts and saved libraries.");
    $("#accountButton").title="Supabase not configured";
    renderLibrary();renderRecommendations();
    return;
  }
  sb.auth.onAuthStateChange(async(_event,session)=>{
    state.session=session;
    await refreshAuth();
  });
  await refreshAuth();
}
init();
