// Copy this file to config.js and replace the placeholders.
// IMPORTANT: use only your Supabase publishable/anon key in browser code.
// Never put a service_role/secret key here.

window.BOOKNEST_CONFIG = {
  supabaseUrl: "https://YOUR-PROJECT.supabase.co",
  supabasePublishableKey: "YOUR-PUBLISHABLE-KEY"
};
