# Library For My Love — full setup

This version includes:

- Real Open Library book search and covers.
- Supabase email/password accounts.
- Persistent cloud library across devices.
- Reading status: Want to read / Reading / Finished.
- 1–5 star ratings.
- Favorites.
- Book detail modal with ISBN, publication year, and subjects.
- ISBN barcode scanning where the browser supports `BarcodeDetector`.
- Recommendation engine based on authors and subjects in the user's library.
- Row Level Security policies so users can access only their own library rows.
- Installable PWA shell for supported mobile/desktop browsers.
- GitHub Pages deployment workflow.

## 1. Create a Supabase project

Create a project at Supabase.

Then open **SQL Editor** and run every statement in `supabase/schema.sql`.

Supabase Auth supports email/password accounts and integrates with Postgres/RLS. The browser client should use the project's publishable key, never a service-role/secret key.

## 2. Configure the website

Copy:

    config.example.js

to:

    config.js

Open `config.js` and put in:

- your Supabase Project URL
- your Supabase Publishable key (`sb_publishable_...`)

Do not put a `service_role` or secret key in `config.js`. Supabase now recommends publishable keys for browser code; secret keys must remain server-side. Legacy `anon`/`service_role` keys are being deprecated by the end of 2026.

## 3. Configure Auth redirect URLs

In Supabase Authentication settings, configure your local site URL and, when deployed, your production URL.

For local development this project can be served at:

    http://localhost:8000

## 4. Run locally

From this folder:

    python -m http.server 8000

Then visit:

    http://localhost:8000

Do not rely on `file://` for camera/auth testing. Use the local HTTP server.

## 5. Test

Create an account.

Search for a book.

Add it.

Change its reading status.

Rate it.

Favorite it.

Refresh the page.

Sign out and sign back in.

The library should come back from Supabase.

## 6. ISBN scanner

The scanner uses the browser's BarcodeDetector API when available. Camera access also requires a secure context in browsers, so production should use HTTPS.

If unsupported, users can still type an ISBN into the normal search box.

## 7. Open Library

Open Library is being used for human-facing discovery/search and cover display. Their documentation asks applications to cache where possible and says the API is not intended to be used as a high-traffic backend.

For a larger production service, add server-side caching and consider another licensed book-data provider.

## 8. Production hardening

Before public launch:

- Add email verification/recovery testing.
- Configure a custom domain and HTTPS.
- Add rate limiting/server-side caching for book searches.
- Add privacy policy and terms.
- Add database backups/monitoring.
- Add server-side validation for any future privileged operations.
- Never expose Supabase service-role/secret keys to the browser.

## 9. Deploy to GitHub Pages

This repository includes `.github/workflows/pages.yml`, so GitHub Actions can publish the static site. GitHub Pages supports static `index.html` sites and custom Actions workflows.

1. Create a GitHub repository and upload the contents of this folder.
2. Keep `config.js` out of Git; the included workflow generates it during deployment.
3. In the repository, open **Settings → Secrets and variables → Actions** and add these repository secrets:
   - `SUPABASE_URL` — your Supabase project URL
   - `SUPABASE_PUBLISHABLE_KEY` — your `sb_publishable_...` browser key
4. In GitHub, open **Settings → Pages** and select **GitHub Actions** as the source.
5. Push to `main`; the included workflow creates `config.js` and publishes the site.
6. In Supabase Auth URL settings, add the exact production URL for the deployed Library For My Love site.

GitHub Pages sites are public on the internet, so never put passwords, secret keys, service-role keys, or private data in the repository.

## 10. Recommended next production upgrades

- Add a small backend/Edge Function for cached Open Library requests and rate limiting.
- Add privacy policy, terms, and a contact/support page.
- Add account deletion and data export.
- Add pagination/infinite scrolling for large search results.
- Add ISBN-10 normalization and duplicate-edition handling.
- Add richer book metadata and optional manual notes.
- Add automated browser tests for sign-in, search, add/remove, and reading-status changes.
