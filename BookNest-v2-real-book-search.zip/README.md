# BookNest v2

A responsive personal book-library website.

## What's new
- Real book search using the Open Library Search API.
- Search by title, author, keywords, or ISBN.
- Real book cover images when Open Library provides them.
- Detects whether a result is already in the browser's library.
- Add and remove books.
- Library is saved with browser `localStorage`.
- Recommendation section searches for books by authors represented in the library.
- Responsive layout for desktop, Android, and iPhone browsers.

## Run
Open `index.html` in a modern browser with an internet connection.

For best results, serve the folder with a small local web server instead of opening the HTML file directly. For example:

```bash
python -m http.server 8000
```

Then open:
http://localhost:8000

## Data source
Book search and cover data use Open Library's public APIs. Open Library recommends human-facing, low-volume discovery/lookup use and asks applications to cache responses when possible.

## Next major step
The site currently stores each user's library only in that browser. The next step is to add a real backend/database and user accounts so a library can follow the user across devices.
