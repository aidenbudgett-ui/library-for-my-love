const STORAGE_KEY = "booknest-library-v2";
const API = "https://openlibrary.org/search.json";

const starterLibrary = [
  {key:"/works/OL27448W",title:"The Hobbit",author:"J.R.R. Tolkien",rating:5,owned:true,cover_i:8231856,first_publish_year:1937},
  {key:"/works/OL893415W",title:"Dune",author:"Frank Herbert",rating:5,owned:true,cover_i:9254116,first_publish_year:1965},
  {key:"/works/OL82586W",title:"Harry Potter and the Sorcerer's Stone",author:"J.K. Rowling",rating:5,owned:true,cover_i:10521270,first_publish_year:1997}
];

let library = loadLibrary();

const $ = (s) => document.querySelector(s);

function loadLibrary(){
  try{
    const saved = JSON.parse(localStorage.getItem(STORAGE_KEY));
    return Array.isArray(saved) ? saved : starterLibrary;
  }catch{
    return starterLibrary;
  }
}

function saveLibrary(){
  localStorage.setItem(STORAGE_KEY, JSON.stringify(library));
}

function escapeHtml(value=""){
  return String(value).replace(/[&<>"']/g, ch => ({
    "&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"
  }[ch]));
}

function normalizeBook(book, owned=false){
  const author = Array.isArray(book.author_name) ? book.author_name[0] : (book.author || "Unknown author");
  const isbn = Array.isArray(book.isbn) ? book.isbn[0] : (book.isbn || "");
  return {
    key: book.key || book.id || `${book.title}-${author}`,
    title: book.title || "Untitled",
    author,
    rating: Number(book.rating) || 0,
    owned,
    cover_i: book.cover_i || null,
    first_publish_year: book.first_publish_year || "",
    isbn
  };
}

function isOwned(book){
  return library.some(b => b.key === book.key || (
    b.title.toLowerCase() === book.title.toLowerCase() &&
    b.author.toLowerCase() === book.author.toLowerCase()
  ));
}

function stars(n){
  if(!n) return "";
  const rounded = Math.max(0, Math.min(5, Math.round(n)));
  return "★".repeat(rounded) + "☆".repeat(5-rounded);
}

function coverMarkup(book){
  if(book.cover_i){
    const url = `https://covers.openlibrary.org/b/id/${book.cover_i}-M.jpg`;
    return `<div class="cover"><img loading="lazy" src="${url}" alt="Cover of ${escapeHtml(book.title)}" onerror="this.parentElement.innerHTML='${escapeHtml(book.title)}'"></div>`;
  }
  return `<div class="cover">${escapeHtml(book.title)}</div>`;
}

function card(book){
  const owned = isOwned(book);
  const year = book.first_publish_year ? `<div class="meta">First published ${escapeHtml(book.first_publish_year)}</div>` : "";
  return `<article class="book-card">
    ${coverMarkup(book)}
    <div class="card-body">
      <h3>${escapeHtml(book.title)}</h3>
      <div class="author">${escapeHtml(book.author)}</div>
      ${book.rating ? `<div class="rating" aria-label="${book.rating} out of 5 stars">${stars(book.rating)}</div>` : ""}
      ${year}
      ${owned
        ? `<span class="status">✓ In your library</span><button class="remove" data-remove="${escapeHtml(book.key)}">Remove</button>`
        : `<span class="status not-owned">Not in your library</span><button class="add" data-add="${escapeHtml(book.key)}">+ Add to library</button>`}
    </div>
  </article>`;
}

function renderLibrary(){
  $("#bookCount").textContent = library.length;
  $("#readingCount").textContent = "0";
  $("#wantCount").textContent = "0";
  $("#libraryEmpty").classList.toggle("hidden", library.length > 0);
  $("#libraryGrid").innerHTML = library.length ? library.map(b => card({...b, owned:true})).join("") : "";
}

function renderRecommendations(results=[]){
  const recs = results.filter(b => !isOwned(b)).slice(0,4);
  $("#recommendationEmpty").classList.toggle("hidden", recs.length > 0 || library.length === 0);
  $("#recommendationGrid").innerHTML = recs.map(card).join("");
}

async function searchBooks(query, forRecommendations=false){
  const q = query.trim();
  if(!q) return [];

  const url = `${API}?q=${encodeURIComponent(q)}&limit=12&fields=key,title,author_name,cover_i,first_publish_year,isbn`;
  const response = await fetch(url);
  if(!response.ok) throw new Error("Book search failed.");
  const data = await response.json();
  return (data.docs || []).map(book => normalizeBook(book));
}

async function doSearch(query){
  const q = query.trim();
  $("#clearSearch").hidden = !q;
  if(!q){
    $("#searchResults").classList.add("hidden");
    $("#apiMessage").textContent = "";
    return;
  }

  $("#searchResults").classList.remove("hidden");
  $("#resultCount").textContent = "";
  $("#resultsGrid").innerHTML = `<div class="loading">Searching Open Library…</div>`;
  $("#apiMessage").textContent = "Searching the Open Library catalog…";

  try{
    const results = await searchBooks(q);
    $("#resultCount").textContent = `${results.length} result${results.length === 1 ? "" : "s"}`;
    $("#resultsGrid").innerHTML = results.length
      ? results.map(card).join("")
      : `<div class="empty-state">No books found. Try a different title, author, or ISBN.</div>`;
    $("#apiMessage").textContent = "Search results powered by Open Library.";
    $("#searchResults").scrollIntoView({behavior:"smooth",block:"start"});
  }catch(error){
    $("#resultsGrid").innerHTML = `<div class="error">We couldn't reach the book database. Check your internet connection and try again.</div>`;
    $("#apiMessage").textContent = "";
  }
}

async function updateRecommendations(){
  if(!library.length){
    renderRecommendations([]);
    return;
  }

  const favorite = library[0];
  try{
    const results = await searchBooks(favorite.author);
    renderRecommendations(results);
  }catch{
    $("#recommendationEmpty").classList.remove("hidden");
    $("#recommendationGrid").innerHTML = "";
  }
}

function addBook(key){
  const buttons = document.querySelectorAll("[data-add]");
  let book = null;

  buttons.forEach(btn => {
    if(btn.dataset.add === key){
      const cardEl = btn.closest(".book-card");
      const title = cardEl.querySelector("h3")?.textContent || "Untitled";
      const author = cardEl.querySelector(".author")?.textContent || "Unknown author";
      book = {key,title,author,owned:true,rating:0,cover_i:null,first_publish_year:""};
    }
  });

  if(!book || isOwned(book)) return;
  library.push(book);
  saveLibrary();
  renderLibrary();
  updateRecommendations();
  doSearch($("#search").value);
}

document.addEventListener("click", e => {
  const add = e.target.closest("[data-add]");
  if(add){
    addBook(add.dataset.add);
    return;
  }

  const remove = e.target.closest("[data-remove]");
  if(remove){
    library = library.filter(b => b.key !== remove.dataset.remove);
    saveLibrary();
    renderLibrary();
    updateRecommendations();
    if($("#search").value) doSearch($("#search").value);
  }
});

$("#searchForm").addEventListener("submit", e => {
  e.preventDefault();
  doSearch($("#search").value);
});

$("#search").addEventListener("input", e => {
  if(!e.target.value.trim()){
    doSearch("");
  }
});

$("#clearSearch").addEventListener("click", () => {
  $("#search").value = "";
  doSearch("");
  $("#search").focus();
});

document.querySelectorAll(".quick-search button").forEach(button => {
  button.addEventListener("click", () => {
    $("#search").value = button.dataset.query;
    doSearch(button.dataset.query);
  });
});

renderLibrary();
updateRecommendations();
